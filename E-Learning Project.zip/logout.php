<?php 
	session_start();

		header('location:E-learning_Home_signin.html');

	session_destroy();
?>